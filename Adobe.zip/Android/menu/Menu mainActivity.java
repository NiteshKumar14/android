package com.example.class_i.menu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.item_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.red:
                displayText("Red");
                return true;
            case R.id.green:
                displayText("Green");
                return true;
            case R.id.blue:
                displayText("Blue");
                return true;
            case R.id.yellow:
                displayText("Yellow");
                return true;
            case R.id.violet:
                displayText("Violet");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void displayText(String text) {
        TextView displayTextView = findViewById(R.id.display_text_view);
        displayTextView.setText(text);
    }
}
