package com.example.class_i.insta_transport;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.*;
import android.content.Intent;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText usernameText=findViewById(R.id.edit_user);
        final EditText passwordText=findViewById(R.id.edit_password);
        final Context context = this;

        Button loginButton=findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String emailString=usernameText.getText().toString();
                String passwordString=passwordText.getText().toString();

                String correctEmail="admin";
                String correctPass="admin";
                if(passwordString.equals(correctPass)&&emailString.equals(correctEmail))
                {
                    Toast.makeText(LoginActivity.this,"Correct Email and Password",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(context,Receiver_details.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(LoginActivity.this,"Incorrect Email and Password",Toast.LENGTH_LONG).show();
                }


            }
        });
    }
}
