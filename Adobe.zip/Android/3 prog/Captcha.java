package com.example.class_i.myapplication;


import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.*;

import java.util.Random;


public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final TextView loginEditText=findViewById(R.id.captcha);
        final EditText passwordEditText = findViewById(R.id.enter);

        ImageButton loginButton = findViewById(R.id.imageButton);
        String alphanum1="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        String captcha2="";
        for(int i=0;i<7;i++)
        {
            captcha2+=alphanum1.charAt(new Random().nextInt(alphanum1.length()));
        }
        final String noob=captcha2;
        final Context context = this;

        loginEditText.setText(noob);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String captcha = loginEditText.getText().toString();

                String enteredString = passwordEditText.getText().toString();





                if (captcha.equals(enteredString)) {

                    Toast.makeText(Main2Activity.this, "Correct Captcha Entered ", Toast.LENGTH_LONG).show();


                } else {

                    Toast.makeText(Main2Activity.this, "Incorrect captcha Entered ", Toast.LENGTH_LONG).show();

                }
            }
        });

    }
}


