package com.example.tarunverma.captcha;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Button redButton = findViewById(R.id.button);
        Button greenButton = findViewById(R.id.button2);
        Button blueButton = findViewById(R.id.button3);

        redButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String color = "red";
                setActivityBackgroundColor(color);
            }
        });
           greenButton.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   String color = "blue";
                   setActivityBackgroundColor(color);
               }
           });
        blueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String color = "cyan";
                setActivityBackgroundColor(color);
            }
        });
            }
            private void setActivityBackgroundColor(String color) {
        View view = this.getWindow().getDecorView();
        view.setBackgroundColor(Color.parseColor(color));
        }
    }

