package com.example.class_i.departmentlist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        int position = getIntent().getIntExtra("pos", 0);
        String[] teachers = new String[] {
                "TIC: CS" ,
                "TIC: Physics" ,
                "TIC: English" ,
                "TIC: Maths"
        };
        TextView teacherTextView = findViewById(R.id.teacherTextView);
        teacherTextView.setText(teachers[position]);
    }
}
